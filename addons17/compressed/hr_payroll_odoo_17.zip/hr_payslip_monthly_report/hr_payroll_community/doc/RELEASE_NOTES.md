## Module <hr_payroll_community>
#### 28.11.2023
#### Version 17.0.1.0.0
#### ADD

- Initial commit for Odoo17 Payroll

#### 06.06.2024
#### Version 17.0.1.0.1
#### UPDT

- Updated payroll report
