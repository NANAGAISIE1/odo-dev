## Module <hr_payslip_monthly_report>
#### 18.12.2023
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Payroll Advanced Features
