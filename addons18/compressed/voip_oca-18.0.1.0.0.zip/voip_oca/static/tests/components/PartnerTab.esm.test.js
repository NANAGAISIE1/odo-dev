/*
    Copyright 2025 Dixmit
    License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
*/
import {click, start, startServer} from "@mail/../tests/mail_test_helpers";
import {expect, test} from "@odoo/hoot";
import {animationFrame} from "@odoo/hoot-dom";
import {defineVoipModels} from "../voip_test_helpers.esm";

// As we use mail as a dependancy, we need to declare models.
defineVoipModels();

test("Check Partner Tab", async () => {
    const pyEnv = await startServer();
    pyEnv["res.partner"].create({
        name: "Test Partner",
        display_name: "Test Partner",
        mobile: "123456789",
    });
    pyEnv["res.partner"].create({
        name: "Test Partner 2",
        display_name: "Test Partner",
        mobile: "123456789",
    });
    await start();
    expect(".o_menu_systray .o_nav_entry[title='Softphone']").toHaveCount(1);
    click(".o_menu_systray .o_nav_entry[title='Softphone']");
    await animationFrame();
    expect(".o_voip_softphone").toHaveCount(1);
    click(".o_voip_softphone li a[name='partner_list']");
    await animationFrame();
    expect(".o_voip_softphone .o_voip_partner_item").toHaveCount(2);
    click(".o_voip_softphone .o_voip_partner_item", {text: "Test Partner"});
    await animationFrame();
    expect(".o_voip_softphone .o_voip_partner_header").toHaveCount(1);
    expect(".o_voip_softphone .o_voip_partner_actions").toHaveCount(1);
    expect(".o_voip_softphone .o_voip_partner_activity").toHaveCount(0);
});
