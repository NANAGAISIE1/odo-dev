Multi-company Switcher Single Mode
============================
Odoo module for switching company only in single mode.
